module.exports = {
    publicPath: './'
};